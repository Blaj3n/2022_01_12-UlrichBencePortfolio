# importálás
import metodus

# a nem szükséges metódusokat kikommenteljük
metodus.napok()
metodus.szo_hossz()
