# globális változók helye
het = {
        1: "Hétfő",
        2: "Kedd",
        3: "Szerda",
        4: "Csütörtök",
        5: "Péntek",
        6: "Szombat",
        7: "Vasárnap",
    }


# 1. Írasd ki a hét napjait, ha a bemenet [1, 7] lehet
# (hibaüzenet jöjjön, ha nem ebben az intervallumban van a bemenet)!
def napok():
    nap = int(input("Kérek egy számot (1-től 7-ig): "))
    print(het.get(nap, "Rossz érték"))


def alszunk_e():
    nap = int(input("Kérek egy számot (1-től 7-ig): "))
    if nap == 1:
        print("Még aludnék.")


# 2. Írasd ki egy bekért szó alapján, hogy “rövid” (max. 3 karakteres), “közepes”
# ([4, 6] karakteres), hosszú (min. 7 karakteres)!
def szo_hossz():
    hossz = {
        3: "rövid",
        4: "közepes",
        5: "közepes",
        6: "közepes",
        7: "hosszú",
    }
    szo = int(input("Kérek egy számot (3-tól 7-ig)"))
    print(hossz.get(szo, "Rossz érték"))


# Kérj be egy tetszőleges szöveget, majd írasd ki a mondat fajtáját
# a mondatvégi jel alapján (kérdő, állító, felszólító/óhajtó, hibás...)!
def mondat_vegi_jel():
    jel = {
        '.': "Állító mondat",
        '!': "Óhajtó/felszólító mondat",
        '?': "Kérdő mondat",
    }
    mondat = input("Kérek egy szöveget: ")
    print(jel.get(mondat[-1], "Hibás mondat."))