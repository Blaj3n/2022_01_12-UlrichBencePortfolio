import random
# 2021.11.22


# globális változó
lista2 = []
for i in range(10):
    lista2.append(random.randint(10, 100))
print(f"Véletlen lista: {lista2}")
lista3 = [23, 56, 7]
lista4 = ["krumpli", "kecske", "bármi"]
lista5 = ["krumpli", "kecske", "bármi", "alma"]

# 2. Egy úszóverseny végeredménye alapján határozzuk meg, hogy a versenyzők hány százaléka teljesítette
# az olimpiai induláshoz szükséges szintet!
# Konkrét feladat: 20 véletlen adat másodpercben (50 és 70 közötti egész szám), az olimpiai induláshoz 1 perc alatt
# kell teljesíteni 100 méter gyorsban.
# Hányan teljesítették? Hány százaléka az indulóknak?
# Megszámlálás tétel


def olimpia(also_hatar=45, felso_hatar=70, szint=55):  # also_hatar, felso_hatar
    db = 0
    lista1 = []
    for i in range(20):
        lista1.append(random.randint(also_hatar, felso_hatar))
    print(f"Az eredmények mp-ben: {lista1}")
    for i in range(len(lista1)):
        if lista1[i] < szint:
            db += 1
    print(f"A szintidőt teljesítők száma: {db}, százalékban kifejezve: {db/len(lista1):.2%}")


# 13. Add meg 10 véletlen szám alapján a 100-hoz legközelebb eső számot! (A véletlen számok [10;100] között lehetnek.)
# Maximumkiválasztás tétel
def fel13(lista):
    # első elem megjegyzése
    legnagyobb = lista[0]
    for i in range(1, len(lista)):
        if lista[i] > legnagyobb:
            legnagyobb = lista[i]
    print(f"A legnagyobb eleme a listának: {legnagyobb}.")


# az ABC-ben legelső nevet írasd ki!
def fel13_beta(lista):
    # első elem megjegyzése
    legelso = lista[0]
    for i in range(1, len(lista)):
        if lista[i] < legelso:
            legelso = lista[i]
    print(f"A legelső eleme a listának az ABC-ben: {legelso}.")


# add meg egy lista étlagát 2 tizedes jegyre kerekítve!
# Sorozatszámítás tétele
def atlag(lista, tizedes):
    osszeg = 0
    for i in range(len(lista)):
        osszeg += lista[i]
    print(f"A lista átlaga: {osszeg/len(lista):.{tizedes}f}")


# fűzzük össze a lista elemeit "*" jellel!
def osszefuzes(lista):
    mondat = ""
    for i in range(len(lista)):
        mondat += lista[i] + "*"
    print(f"Az összefűzött elem: {mondat[:-1]}")


# Add meg a 4-gyel osztható kétjegyű számok számát!
def megszamlal():
    db = 0
    for i in range(10, 100):
        if i % 4 == 0:
            db += 1
    print(f"A 4-gyel osztható kétjegyű számok száma: {db}.")