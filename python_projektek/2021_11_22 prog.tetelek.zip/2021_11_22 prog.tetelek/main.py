import osszefoglalas
# osszefoglalas.olimpia(szint=55)
# osszefoglalas.fel13(osszefoglalas.lista3)
# osszefoglalas.fel13_beta(osszefoglalas.lista5)
# osszefoglalas.atlag(osszefoglalas.lista2, 0)
osszefoglalas.osszefuzes(osszefoglalas.lista5)
osszefoglalas.megszamlal()
