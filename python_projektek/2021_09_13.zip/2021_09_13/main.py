# 2021.09.13 Programozási alapok

# Python 1 4. feladat
# Kérj be 3 számot, majd írasd ki a számtani közepüket!
# a = int (input("Kérek egy egész számot: "))
# b = int (input("Kérek egy egész számot: "))
# c = int (input("Kérek egy egész számot: "))
# számtani közép kiszámítása
# print("Számtani közép: ", (a+b+c)/3)
# mértani közép kiszámítása
# print("Mértani közép: ", (a*b*c)**(1/3))

# Python 2 alapok
# többszörös elágazás
# a = int (input("Kérek egy egész számot: "))
# b = int (input("Kérek egy egész számot: "))
# if b < a:
#     print ("A kisebb szám:", b)
# elif a < b:
#     print ("A kisebb szám:", a)
# else:
#     print ("A számok egyenlőek: ")

# több sor kikommentelése egyszerre Code - Comment with Line Comment
# egymásba ágyazott döntés
# x = int (input("Kérek egy számot: "))
# if x > 10:
#     print("A szám nagyobb mint 10.")
#     if x > 20:
#         print("A szám nagyobb mint 20.")
#     else:
#         print("A szám nem nagyobb mint 20.")
# else:
#     print("A szám nem nagyobb mint 10.")

# Ellenörző feladatok
# https://docs.google.com/document/d/13eWOz6B3qfcINrmWiP-FVmyPycwopUyDGyJJ29SJhXg/edit
# 1. feladat
# Kérj be 3 számot, majd írasd ki azt, hogy “Van egyenlő a számok között!”, ha ez igaz állítás,
# és “Nincs egyenlő a számok között!”, ha utóbbi az igaz állítás!
# a = int(input("Kérek egy egész számot: "))
# b = int(input("Kérek egy egész számot: "))
# c = int(input("Kérek egy egész számot: "))
# if a == b or a == c or b == c:
#     print("Van egyenlő köztük.")
# else:
#     print("Nincs egyenlő köztük.")

# 2. feladat
# Egy 100 pontos dolgozatot alapul véve írasd ki a szerinted igazságos pontozás és a bekért szám (mint eredmény)
# alapján, hogy jeles, jó, közepes, elégséges vagy elégtelen a dolgozat!
# a = int (input("Kérek egy számot 1-től 100-ig: "))
# if a > 100:
#     print("Kérlek adj meg egy kisebb számot")
# elif a <= 29:
#     print("Elégtelen")
# elif a <= 49:
#     print("Elégséges")
# elif a <= 74:
#     print("Közepes")
# elif a <= 84:
#     print ("Jó")
# elif a >= 85:
#     print ("Jeles")

# 3. feladat
# A program kérjen be a konzolról egy egész számot! Ha a szám egyjegyű, akkor a program írja ki
# a konzolra a számot megelőző és követő egész számot, egyébként ne írjon ki semmit!
# a = int(input("Kérek egy számot: "))
# if a > 9 or a < -9:
#     print("Egy jegyű számot adj meg")
# else:
#     print(a+1)
#     print(a-1)

# 4. feladat
# Írd meg a leghatékonyabb változatát 2 bekért szám növekvő sorrendbe tételének
# (az értékek legyenek növekvő sorrendben)! Pl. a = 6, b = 3 esetén az átalakítás után a értéke 3, b értéke 6 lesz.
# a = int(input("Kérek egy számot: "))
# b = int(input("Kérek egy számot: "))
# if a > b:
#     #ideiglenes változó létrehozása, és az értékek megcserélése
#     c = b
#     b = a
#     a = c
# print (a, b)

# 5. feladat
# try:
#     sz = int(input("Kérek egy 3 jegyű számot: "))
# except:
#     sz = 0
#     print("Nem szám!")
#     if sz < 100 or sz > 999:
#         print("Rossz szám!")
#     else:
#         s1 = sz // 100
#         s2 = (sz // 10) % 10
#         s3 = sz % 10
#         print(s1, s2, s3)
#     input()

# Python Ellenörző feladatok - Elágazások gyakorlása

# 1. feladat
# A program olvasson be a konzolról egy egész számot! A program döntse el, hogy a megadott szám páros vagy páratlan,
# és írja ki az eredményt a konzolra!
# a = int(input("Kérek egy egész számot: "))
# if (a % 2) == 0:
#     print("A szám páros")
# else:
#     print("A szám páratlan")

# 2. feladat
# A program  olvasson be a konzolról egy valós számot! A program számítsa ki a szám abszolút értékét,
# és írja ki az eredményeket a konzolra! A számításhoz függvény helyett elágazást használj!
# a = float(input("Kérek egy valós számot: "))
# if a<0:
#     print(a * (-1))
# else:
#     print(a)
# 3. feladat
# A program számítsa ki egy beolvasott valós szám négyzetgyökét! A program adjon hibaüzenetet,
# ha a felhasználó negatív számból akar gyököt vonni!
# a = float(input("Kérek egy valós számot: "))
# if a >=0:
#     print("a szám négyzetgyöke: ", a**(1/2))
# else:
#     print("error")

# 4. feladat
# A program két beolvasott számot összehasonlítva írja közéjük a megfelelő relációs jelet (<, >, =)!
a = int(input("Kérek egy egész számot: "))
b = int(input("Kérek egy egész számot: "))
if a > b:
    print(a, ">", b)
elif a == b:
    print(a, "=", b)
else:
    print(a, "<", b)
