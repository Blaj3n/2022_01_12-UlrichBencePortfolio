# 2021.09.10
# a = 4
# b = 6
# print("Összeg:", a+b)

# Python 1
# 1. feladat Kérj be 2 szöveget, majd írasd ki egymás után (pl. vezetéknév keresztnévvel)!
# vnev = input('Add meg a vezetéknevedet: ')
# knev = input('Add meg a keresztnevedet: ')
# print(vnev + knev)
# 2. feladat Legyen a nev változó értéke az előbb megadott vezetéknév és keresztnév szóközzel összefűzve!
vnev = input('Add meg a vezetéknevedet: ')
knev = input('Add meg a keresztnevedet: ')
print(vnev + "", knev)
# 3. feladat Kérj be egy nevet és egy számot, majd írasd ki az ilyen nevű ember életkorát, pl. “Huba 19 éves.”
# nev = input('Add meg a keresztnevedet: ')
# kor = input('Add meg a korodat: ')
# print(nev + "", kor, "éves.")
# 4. feladat Kérj be 3 számot, majd írasd ki a számtani közepüket!
# https://www.youtube.com/watch?v=cybMiQYuEwc
# szam = int(input("Add meg hány számot szeretnél megadni: "))
# osszeg = 0
#
# for i in range(szam):
#     szamok = float(input("Adj meg egy számot: "))
#     osszeg += szamok
#
# atlag = osszeg / szam
# print("A számok számtani közepe:", atlag)
# 5. Kérj be egy 2 jegyű (nehezebb: 3 jegyű) számot, és írd ki space-kkel elválasztva a számjegyeit!

# ez a komment helye
# szöveg kiíratása
# vnev = input('Add meg a vezetéknevedet: ')
# knev = input('Add meg a keresztnevedet: ')
# kor = input('Add meg az életkorod: ')
# print(vnev + "", knev, kor, "éves !")
# szöveg és szám összefűzése: , szóközzel lesz elválasztva
# print ("Hello", knev, "!")
# ugyanez + jellel elválasztva
# print ("Hello "+knev+"!")

# szám bekérése
# a = int(input("Kérek egy egész számot: "))
# b = float(input("Kérek egy tört számot: "))
# print("A két szám szorzata: ", a*b)
