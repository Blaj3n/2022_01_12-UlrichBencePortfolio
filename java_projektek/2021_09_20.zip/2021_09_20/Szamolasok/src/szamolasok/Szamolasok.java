package szamolasok;

public class Szamolasok {

    public static void main(String[] args) {
        //sout tab
        /* mind jó */
        System.out.println(3*7);
        System.out.println(7/3);
        System.out.println(3-7);
        System.out.println(3+7);
        
        /* mind jó */
        System.out.println(3*7 + " = 3*7");
        System.out.println(7/3 + " = 7/3");
        System.out.println(3-7 + " = 3-7" );
        System.out.println(3+7 + " = 3+7");
        
        /* NEM mind jó... */
        System.out.println("3*7 = " + 3*7);
        System.out.println("7/3 = " + 7/3);
        //System.out.println("3-7 = " + 3-7);
        System.out.println("3+7 = " + 3+7);
        
        /* Megoldás */
        System.out.println("3*7 = " + 3*7);
        System.out.println("7/3 = " + 7/3);
        System.out.println("3-7 = " + (3-7));
        System.out.println("3+7 = " + (3+7));
    }
    
}
