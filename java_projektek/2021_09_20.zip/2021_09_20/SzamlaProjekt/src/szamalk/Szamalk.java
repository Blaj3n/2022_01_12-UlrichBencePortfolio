package szamalk;

public class Szamalk {

    public static void main(String[] args) {
        System.out.println("xxxxxxxxxxxxxxxx");
        System.out.println("    Nyugta      ");
        System.out.println("xxxxxxxxxxxxxxxx");
        System.out.println("Tétel 1  350 FT");
        System.out.println("Tétel 2  600 FT");
        System.out.println("Tétel 3  90 FT");
        System.out.println("----------------");
        System.out.println("Összesen: 1040 Ft");
        System.out.println("================");
        
        System.out.println("________________");
        System.out.println(" Dátum");
        System.out.println("         _______");
        System.out.println("           Név");
        System.out.println("****************");
        System.out.println("        CÉG     ");
        System.out.println("****************");
    }
}