package szamlaprojekt;

public class SzamlaProjekt {

    public static void main(String[] args) {
        System.out.println("********************");
        System.out.println("       Nyugta");
        System.out.println("********************");
        
//        System.out.print("Tétel 1.:");
//        System.out.print("   ");
//        System.out.println("350 Ft");
        System.out.println("Tétel 1.:   350 Ft");
        System.out.println("Tétel 2.:   600 Ft");
        System.out.println("Tétel 3.:    90 Ft");
        System.out.println("--------------------");
        System.out.println("Összesen:  1040 Ft");
        System.out.println("====================");
        
        System.out.println("________");
        System.out.println(" Dátum");
        System.out.println("            ________");
        System.out.println("              Név");        
        System.out.println("********************");
        System.out.println("        CÉG");
        System.out.println("********************");
    }
}