package elsojavaproject;

public class ElsoJavaProject {

    public static void main(String[] args) {
        System.out.print("helló");
        System.out.print(" ");
        System.out.print("Java");
        System.out.println();
    }//main
    
}//class