package feltetelek;
public class Feltetelek4_if_else_if {
    public static void main(String[] args) {
        int szam = -10;
        String valasz;
        if(szam > 0){
            valasz = "pozitív";
        }else if(szam < 0){
            valasz = "negatív";
        }else{
            valasz = "nulla";
        }
        
        System.out.printf("%d előjele: %s\n", szam, valasz);
        
        System.out.println("-------------------");
        
        System.out.println("Milyen szín van megadva?");
        /* lehetséges értékek: piros, fehér,zöld */ 
        String szin = "piros";
        if(szin == "piros"){
            System.out.println("a \"piros\" színt adtad meg!");
        }else if(szin == "fehér"){
            System.out.println("a \"fehér\" színt adtad meg!");
        }else if(szin == "zöld"){
            System.out.println("a \"zöld\" színt adtad meg!");
        }else{
            System.out.println("NEM TUDOM!");
        }
        
    }
}
