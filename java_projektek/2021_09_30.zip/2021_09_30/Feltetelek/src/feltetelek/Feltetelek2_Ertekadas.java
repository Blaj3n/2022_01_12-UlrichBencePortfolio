package feltetelek;

public class Feltetelek2_Ertekadas {
    //psvm tab
    public static void main(String[] args) {
        boolean esik = false;//csak true v. false
        System.out.println("esik értéke: " + esik);
        System.out.println("Esik az eső?");
        /* valasz értéke esik értékétől függ
                                true  : false */
        String valasz = esik ? "igen" : "nem";
        System.out.println(valasz);
        
        int szam = 0;
        boolean elojel = szam > 0;
        /* valasz értéke elojel értékétől függ
                            true    :    false */
        valasz = elojel ? "pozitív" : "NEM pozitív";
        System.out.printf("%d előjele: %s\n", szam, valasz);
    }
}
