package ittapiros;

import java.util.Random;

public class IttAPiros {

    public static void main(String[] args) {
        /* golyó elhelyezése a pohár alatt */
        Random rnd = new Random();
        //int golyoHelye = 2;
        int golyoHelye = rnd.nextInt(3) + 1;
        
        /* kezdés kirajzolása */
        System.out.println("Hol a golyó?");
        System.out.println("_ _ _");
        System.out.println("1 2 3");
        
        /* tipp "bekérése" */
        int tipp = 2;//Scanner, használata mint Random osztály
        System.out.printf("tipp: %d\n", tipp);
        
        /* tipp ellenőrzése: 1,2,3 lehet csak!*/
            
        /* eredmény */
        String valasz = "NEM talált!";
        if(tipp == golyoHelye){
            //System.out.printf("Talált! (%d->%d)\n",golyoHelye, tipp);
            valasz = "Talált!";
        }/*else{
            System.out.printf("NEM talált! (%d->%d)\n",golyoHelye, tipp);
        }*/

        System.out.printf("%s (%d->%d)\n",valasz, golyoHelye, tipp);
    } 
}