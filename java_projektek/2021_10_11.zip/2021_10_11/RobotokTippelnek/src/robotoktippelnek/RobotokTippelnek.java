package robotoktippelnek;

import java.util.Random;

public class RobotokTippelnek {

    public static void main(String[] args) {
        Random rnd = new Random();
        int also = 1, felso = 10;
        int foRobotTipp = rnd.nextInt(felso) + also;
        int kisRobot1 = rnd.nextInt(felso) + also;
        int kisRobot2 = rnd.nextInt(felso) + also;
        int kisRobot3 = rnd.nextInt(felso) + also;
        
        /* TESZTELÉSRE */
        /* foRobotTipp = 6;
        kisRobot1 = 3;
        kisRobot2 = 1;
        kisRobot3 = 4;*/
        /* TESZT VÉGE */
        
        System.out.println("A gondolt szám: " + foRobotTipp);
        System.out.println("1. robot tippje: " + kisRobot1);
        System.out.println("2. robot tippje: " + kisRobot2);
        System.out.println("3. robot tippje: " + kisRobot3);
        boolean voltTalalat = false;
        String szoveg = "";
        if(foRobotTipp == kisRobot1){
            //System.out.println("Az 1. robot eltatlálta!");
            szoveg = "Az 1. robot eltalálta!\n";
            voltTalalat = true;
        }
        if(foRobotTipp == kisRobot2){
            //System.out.println("A 2. robot eltatlálta!");
            szoveg = szoveg + "Az 2. robot eltalálta!\n";
            voltTalalat = true;
        }
        if(foRobotTipp == kisRobot3){
            //System.out.println("A 3. robot eltatlálta!");
            szoveg = szoveg + "Az 3. robot eltalálta!\n";
            voltTalalat = true;
        }
        
        if(!voltTalalat){
            System.out.println("Egyik robot sem találta el");
        }else{
            System.out.println(szoveg);
        }
    }
    
}
